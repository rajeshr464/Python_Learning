"""
strs = [“hello”, “waltham”,”I”, “am”, “here”] 
orderInd = [3,4,1,0,2] 



expected Output:
In this case, it will be [ (“am”, 1), (“here”, “2”), (“waltham”,2),     (“hello”, 2), (“I”, 1)]

"""
count = 0
word = []
vowels = " "
output = []
input_string = input("Please enter any sentanse: ")
input_string_list = input_string.split(" ")
for listword in input_string_list:
    word = listword
    for letter in word:
      if letter == "a" or letter == "e" or letter == "i" or letter           == "o" or letter == "u":
        count = count + 1
    output.append((word, count))
    count = 0
print(output)


  
    
    
