def convert_to_words(numbers):
  number = {
      "1": "One",
      "2": "Two",
      "3": "Three",
      "4": "Four",
      "5": "Five",
      "6": "Six",
      "7": "Seven",
      "8": "Eight",
      "9": "Nine",
      "0": "Zero"
  }
  output = ""
  for i in numbers:
    output = output + number[i] + " "
  return output


def find_max(numbers):
  max = numbers[0]
  for number in numbers:
    if number > max:
      max = number
  return max


def find_min(numbers):
  min = numbers[0]
  for number in numbers:
    if number < min:
      min = number
  return min


def find_vowels(input_string):
  count = 0
  word = []
  vowels = " "
  output = []
  input_string_list = input_string.split(" ")
  for listword in input_string_list:
    word = listword
    for letter in word:
      if letter == "a" or letter == "e" or letter == "i" or letter ==          "o" or letter == "u":
        count = count + 1
    output.append((word, count))
    count = 0
  return output