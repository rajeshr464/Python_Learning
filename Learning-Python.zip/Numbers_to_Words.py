import my_module
number = input("Please enter any number: ")
print(my_module.convert_to_words(number))
print(my_module.find_max(number))
print(my_module.find_min(number))